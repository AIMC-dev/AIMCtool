export default function Home() {
  return (
    <main>
      <h1>Welkom bij AIMC Tool</h1>
      <p>Upload en stem op memes – powered by AI & memes 🦎</p>
    </main>
  );
}
